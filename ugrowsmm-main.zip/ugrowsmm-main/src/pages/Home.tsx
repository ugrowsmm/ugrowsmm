import TierBadge from '../components/TierBadge'
import ReviewsMarquee from '../components/ReviewsMarquee'
import BonusBanner from '../components/BonusBanner'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Check,
  ChevronDown,
  Clock,
  Code2,
  ShieldCheck,
  Sparkles,
  Wallet,
  Zap,
} from 'lucide-react'
import {
  PLATFORM_LABEL,
  SERVICES,
  formatINR,
  type Platform,
  type Service,
} from '../lib/data'
import { PlatformIcon } from '../components/PlatformIcon'
import { LogoGlyph, Wordmark } from '../components/Logo'
import InstallButton from '../components/InstallButton'
import { scrollToSection } from '../lib/smoothScroll'
import { useStore } from '../lib/store'
import { REFERRAL_PERCENT_DEFAULT, USERS_LABEL } from '../lib/config'

const SHOWCASE_IDS = [
  'ig-followers',
  'ig-likes',
  'yt-views',
  'tg-members',
  'sp-plays',
]

const PLATFORMS: Platform[] = [
  'instagram',
  'youtube',
  'x',
  'facebook',
  'telegram',
  'spotify',
]

const MOCK_ORDERS = [
  { platform: 'instagram' as const, name: 'Instagram Followers', qty: '5,000', pct: 64 },
  { platform: 'youtube' as const, name: 'YouTube Views', qty: '25,000', pct: 100 },
  { platform: 'facebook' as const, name: 'Facebook Page Likes', qty: '10,000', pct: 82 },
]

const FAQS = [
  {
    q: 'Is UGrowSMM safe for my accounts?',
    a: 'We never ask for passwords or two-factor codes — only public profile, post or channel links. Orders use gradual delivery and quality tiers, with 30-day refill protection on eligible services to keep growth looking natural.',
  },
  {
    q: 'How quickly do orders start?',
    a: 'Most services start within minutes. The catalogue shows an estimated start window for every service, and your dashboard tracks live progress from 0 to 100%. Our current average start time is around 42 minutes.',
  },
  {
    q: 'What happens if an order under-delivers?',
    a: 'Open the order in your history and contact support with the order ID. We will restart, refill or refund the undelivered portion depending on the service and verification. Full details are in our Refund Policy.',
  },
  {
    q: 'Can agencies and resellers automate orders?',
    a: 'Yes. Every account includes an API key with endpoints to create orders, check status, list services and read your balance. You can rotate the key instantly and pause API access without deleting it.',
  },
  {
    q: 'Do I need a subscription or minimum spend?',
    a: 'No subscription. UGrowSMM runs on a prepaid INR wallet, so you only pay for the orders you place. Top-ups are available from ₹100 and are paid instantly through UPI apps like PhonePe, Google Pay, Paytm and BHIM.',
  },
]

function ServiceCard({ service }: { service: Service }) {
  return (
    <Link to="/login" className="service-card" style={{ display: 'flex' }}>
      <div className="top">
        <span className={`platform-tile ${service.platform}`}>
          <PlatformIcon platform={service.platform} />
        </span>
        <div className="row" style={{ gap: 6 }}>
          {service.badge ? <span className="badge badge-lime">{service.badge}</span> : null}
          <TierBadge quality={service.quality} />
        </div>
      </div>
      <div>
        <div className="tiny faint" style={{ fontWeight: 700, letterSpacing: '0.08em' }}>
          {PLATFORM_LABEL[service.platform].toUpperCase()} · {service.category.toUpperCase()}
        </div>
        <div className="name">{service.name}</div>
        <div className="cat">{service.description}</div>
      </div>
      <div className="service-meta-row">
        <span>Min {service.min.toLocaleString('en-IN')}</span>
        <span>·</span>
        <span>{service.avgTime}</span>
      </div>
      <div className="bottom">
        <div className="rate">
          {formatINR(service.rate, 0)} <span>/ 1k</span>
        </div>
        <span className="badge badge-violet">
          Order <ArrowUpRight />
        </span>
      </div>
    </Link>
  )
}

export default function Home() {
  const { state } = useStore()
  const [openFaq, setOpenFaq] = useState<number | null>(0)
  const panelHref = state.signedIn ? '/' : '/login'

  useEffect(() => {
    document.title = 'UGrowSMM — Premium SMM Panel'
  }, [])

  const showcase = SHOWCASE_IDS.map((id) => SERVICES.find((s) => s.id === id)).filter(
    (s): s is Service => Boolean(s),
  )

  return (
    <div className="mkt-shell">
      <header className="mkt-header">
        <Link to="/" className="brand">
          <span className="brand-mark">
            <LogoGlyph size={23} />
          </span>
          <span>
            <Wordmark />
            <span className="brand-sub">SMM Panel</span>
          </span>
        </Link>

        <nav className="mkt-nav" aria-label="Homepage">
          <button type="button" onClick={() => scrollToSection('#features')}>
            Features
          </button>
          <button type="button" onClick={() => scrollToSection('#services')}>
            Services
          </button>
          <button type="button" onClick={() => scrollToSection('#how')}>
            How it works
          </button>
          <button type="button" onClick={() => scrollToSection('#faq')}>
            FAQ
          </button>
        </nav>

        <div className="mkt-header-actions">
          <Link to={panelHref} className="btn btn-ghost btn-sm hide-mobile">
            {state.signedIn ? 'Dashboard' : 'Sign in'}
          </Link>
          <Link to={panelHref} className="btn btn-primary btn-sm">
            Open panel <ArrowRight />
          </Link>
        </div>
      </header>

      <main>
        <section className="mkt-hero">
          <div className="mkt-hero-copy">
            <span className="eyebrow">
              <Sparkles size={12} /> UGrowSMM · Premium SMM panel
            </span>
            <h1>
              Grow louder.
              <br />
              <span className="grad-text">Ship results</span> <span className="grad-cool">faster.</span>
            </h1>
            <p>
              Followers, likes, views and plays — delivered from one beautifully fast panel. Real
              quality tiers, transparent INR pricing and an API for teams that automate.
            </p>
            <div className="mkt-cta-row">
              <Link to={panelHref} className="btn btn-primary btn-lg">
                Launch the panel <ArrowRight />
              </Link>
              <button
                type="button"
                className="btn btn-ghost btn-lg"
                onClick={() => scrollToSection('#services')}
              >
                Explore services
              </button>
            </div>

            <div className="mkt-proof">
              <div className="faces" aria-hidden="true">
                <span>{USERS_LABEL}</span>
              </div>
              <div>
                <small>Trusted by {USERS_LABEL} creators, agencies &amp; resellers</small>
              </div>
            </div>
          </div>

          <div className="mkt-hero-art">
            <div className="mkt-glow" aria-hidden="true" />
            <div className="mkt-mock">
              <div className="mkt-mock-head">
                <span className="row" style={{ gap: 8 }}>
                  <span className="brand-mark" style={{ width: 26, height: 26, borderRadius: 8 }}>
                    <LogoGlyph size={15} />
                  </span>
                  <b>UGrowSMM panel</b>
                </span>
                <span className="badge badge-green">Popular services</span>
              </div>

              <div className="mkt-mock-balance">
                <div className="tiny faint">Wallet</div>
                <div className="val">Top up in seconds</div>
                <div className="row" style={{ gap: 8, marginTop: 8 }}>
                  <span className="badge badge-lime">From ₹100</span>
                  <span className="tiny faint">UPI · instant</span>
                </div>
              </div>

              <div className="mkt-mock-orders">
                {MOCK_ORDERS.map((order) => {
                  const from = Math.min(...SERVICES.filter((x) => x.platform === order.platform).map((x) => x.rate))
                  return (
                    <div className="mkt-mock-row" key={order.name}>
                      <span className={`platform-tile ${order.platform}`} style={{ width: 30, height: 30 }}>
                        <PlatformIcon platform={order.platform} size={14} />
                      </span>
                      <div className="grow">
                        <div className="n">{order.name}</div>
                        <div className="tiny faint">Starts within minutes</div>
                      </div>
                      <span className="pct">{Number.isFinite(from) ? `From ${formatINR(from, 0)}/1K` : ''}</span>
                    </div>
                  )
                })}
              </div>

              <div className="mkt-mock-foot">
                <span>
                  <Zap size={12} /> Fast start
                </span>
                <span>
                  <ShieldCheck size={12} /> Refill protected
                </span>
              </div>
            </div>

            <div className="mkt-float">
              <span className="mkt-float-icon">
                <BadgeCheck />
              </span>
              <div>
                <b>Secure UPI top-up</b>
                <span>PhonePe, GPay, Paytm, BHIM</span>
              </div>
            </div>
          </div>
        </section>

        <div className="mkt-platforms" aria-label="Supported platforms">
          <span className="mkt-platforms-label">Built for every platform you grow</span>
          <div className="mkt-platforms-list">
            {PLATFORMS.map((platform) => (
              <span className="mkt-platform" key={platform}>
                <PlatformIcon platform={platform} size={15} />
                {PLATFORM_LABEL[platform]}
              </span>
            ))}
          </div>
        </div>

        <section className="mkt-section" id="features">
          <div className="mkt-head">
            <div>
              <span className="eyebrow">Why UGrowSMM</span>
              <h2>
                Every growth tool.
                <br />
                One polished panel.
              </h2>
            </div>
            <p>
              Built for creators who care about quality and agencies who care about speed. No
              spreadsheets, no guesswork, no missed orders.
            </p>
          </div>

          <div className="mkt-features">
            <article className="mkt-feature mkt-feature-lg">
              <span className="mkt-feature-icon">
                <Zap />
              </span>
              <h3>Lightning delivery, without the risk</h3>
              <p>
                Most services start in minutes and drip-feed naturally. Premium profiles and 30-day
                refill protection keep every campaign credible.
              </p>
              <div className="mkt-feature-bars" aria-hidden="true">
                <span style={{ width: '44%' }} />
                <span style={{ width: '68%' }} />
                <span style={{ width: '86%' }} />
                <span style={{ width: '100%' }} />
              </div>
            </article>

            <article className="mkt-feature">
              <span className="mkt-feature-icon cyan">
                <Code2 />
              </span>
              <h3>API-first automation</h3>
              <p>Create orders and poll delivery from your own stack with a single v2 key.</p>
            </article>

            <article className="mkt-feature">
              <span className="mkt-feature-icon lime">
                <Wallet />
              </span>
              <h3>INR wallet, zero subscriptions</h3>
              <p>Top up instantly with PhonePe, GPay, Paytm or BHIM. Pay only for the orders you actually place.</p>
            </article>

            <article className="mkt-feature">
              <span className="mkt-feature-icon pink">
                <ShieldCheck />
              </span>
              <h3>Protection built in</h3>
              <p>Transparent pricing, live order tracking and a real support team when it matters.</p>
            </article>
          </div>
        </section>

        <section className="mkt-section" id="services">
          <div className="mkt-head">
            <div>
              <span className="eyebrow">The catalogue</span>
              <h2>Twenty-one ways to grow.</h2>
            </div>
            <Link to={state.signedIn ? '/services' : '/login'} className="btn btn-ghost btn-sm">
              View full catalogue <ArrowRight />
            </Link>
          </div>

          <div className="service-grid">
            {showcase.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </section>

        <section className="mkt-section" id="how">
          <div className="mkt-head">
            <div>
              <span className="eyebrow">How it works</span>
              <h2>From idea to impact in three steps.</h2>
            </div>
            <p>No onboarding calls, no waiting for approval. Open the panel and launch your first order in under two minutes.</p>
          </div>

          <div className="mkt-steps">
            <div className="mkt-step">
              <span className="mkt-step-num">01</span>
              <h3>Create your free account</h3>
              <p>Sign in with the demo workspace and explore every screen with sample data.</p>
              <span className="mkt-step-icon">
                <Sparkles />
              </span>
            </div>
            <div className="mkt-step">
              <span className="mkt-step-num">02</span>
              <h3>Top up your INR wallet</h3>
              <p>Add funds instantly with PhonePe, GPay, Paytm or BHIM — bonus credit included.</p>
              <span className="mkt-step-icon">
                <Wallet />
              </span>
            </div>
            <div className="mkt-step">
              <span className="mkt-step-num">03</span>
              <h3>Drop a link. Watch it grow.</h3>
              <p>Pick a service, paste your link and track delivery live from your dashboard.</p>
              <span className="mkt-step-icon">
                <Zap />
              </span>
            </div>
          </div>
        </section>

        <section className="mkt-section">
          <div className="mkt-stats">
            <div>
              <b>{SERVICES.length}</b>
              <span>Services across {PLATFORMS.length} platforms</span>
            </div>
            <div>
              <b>{USERS_LABEL}</b>
              <span>Creators & agencies onboard</span>
            </div>
            <div>
              <b>Minutes</b>
              <span>Typical delivery start</span>
            </div>
            <div>
              <b>30 days</b>
              <span>Refill protection</span>
            </div>
          </div>
        </section>

        <section className="mkt-section">
          <div className="mkt-head">
            <div>
              <span className="eyebrow">Loved by creators</span>
              <h2>Don’t take our word for it.</h2>
            </div>
          </div>

          <ReviewsMarquee />
        </section>

        <section className="mkt-section" id="faq">
          <div className="mkt-head">
            <div>
              <span className="eyebrow">Good to know</span>
              <h2>Questions, answered.</h2>
            </div>
            <p>
              Everything you need before your first order. Still unsure? The support team answers
              within one business day.
            </p>
          </div>

          <div className="mkt-faq">
            {FAQS.map((faq, index) => {
              const open = openFaq === index
              return (
                <div className={`mkt-faq-item ${open ? 'open' : ''}`} key={faq.q}>
                  <button
                    type="button"
                    id={`faq-button-${index}`}
                    onClick={() => setOpenFaq(open ? null : index)}
                    aria-expanded={open}
                    aria-controls={`faq-panel-${index}`}
                  >
                    <span>{faq.q}</span>
                    <ChevronDown />
                  </button>
                  <div
                    className="mkt-faq-answer"
                    id={`faq-panel-${index}`}
                    role="region"
                    aria-labelledby={`faq-button-${index}`}
                  >
                    <p>{faq.a}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </section>

        <section className="mkt-section" aria-label="Referral bonus">
          <BonusBanner cta />
          <p className="small muted" style={{ textAlign: 'center', marginTop: 12 }}>
            Creators and resellers earn {REFERRAL_PERCENT_DEFAULT}% of every top-up made by people who join with their code.
          </p>
        </section>

        <section className="mkt-final">
          <div className="mkt-final-inner">
            <span className="eyebrow">
              <Sparkles size={12} /> Ready when you are
            </span>
            <h2>
              Make your next campaign
              <br />
              <span className="grad-text">impossible</span> <span className="grad-cool">to ignore.</span>
            </h2>
            <p>
              Open the UGrowSMM demo panel, explore every screen and place a sample order. No real
              money, no passwords, no risk.
            </p>
            <div className="mkt-final-actions">
              <Link to={panelHref} className="btn btn-lime btn-lg">
                <Sparkles /> Open the UGrowSMM panel
              </Link>
              <InstallButton />
            </div>
            <div className="mkt-final-meta">
              <span>
                <Check /> Secure UPI payments
              </span>
              <span>
                <Check /> 30-day refill protection
              </span>
              <span>
                <Check /> Instant UPI top-up
              </span>
            </div>
          </div>
        </section>
      </main>

      <footer className="mkt-footer">
        <div className="mkt-footer-grid">
          <div className="mkt-footer-brand">
            <Link to="/" className="brand">
              <span className="brand-mark">
                <LogoGlyph size={23} />
              </span>
              <span>
                <Wordmark />
                <span className="brand-sub">SMM Panel</span>
              </span>
            </Link>
            <p>
              The growth operating system for creators, agencies and resellers. One panel, every
              platform, zero guesswork.
            </p>
            <div className="row wrap" style={{ gap: 8 }}>
              <span className="pill">
                <ShieldCheck size={11} /> Secure checkout
              </span>
              <span className="pill">
                <Clock size={11} /> 42m avg start
              </span>
            </div>
          </div>

          <div className="mkt-footer-col">
            <h3>Product</h3>
            <Link to={panelHref}>Panel</Link>
            <button type="button" onClick={() => scrollToSection('#services')}>
              Services
            </button>
            <button type="button" onClick={() => scrollToSection('#features')}>
              Features
            </button>
            <Link to={state.signedIn ? '/api' : '/login'}>{state.signedIn ? 'API & keys' : 'API access'}</Link>
          </div>

          <div className="mkt-footer-col">
            <h3>Legal</h3>
            <Link to="/terms">Terms of Service</Link>
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/refund-policy">Refund Policy</Link>
            <Link to="/cookies">Cookie Policy</Link>
          </div>

          <div className="mkt-footer-col">
            <h3>Get the app</h3>
            <p className="tiny faint">Install UGrowSMM on Android for a full-screen panel.</p>
            <InstallButton />
            <span className="tiny faint">Android · Chrome · Edge</span>
          </div>
        </div>

        <div className="mkt-footer-bottom">
          <span>© 2026 UGrowSMM · Independent SMM panel · Demo UI, no real transactions</span>
          <span className="row" style={{ gap: 14 }}>
            <Link to={panelHref}>{state.signedIn ? 'Dashboard' : 'Sign in'}</Link>
            <Link to="/terms">Terms</Link>
            <Link to="/privacy">Privacy</Link>
          </span>
        </div>
      </footer>
    </div>
  )
}
